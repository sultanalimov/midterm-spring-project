async function fetchUsersWithPosts() {
    try {
        const responseForUsers = await fetch('https://jsonplaceholder.typicode.com/users');
        if (!responseForUsers.ok) {
            throw new Error('Failed to fetch users');
        }
        const users = await responseForUsers.json();

        const usersWithPosts = await Promise.all(users.map(async(user) => {
            const postsResponse = await fetch(`https://jsonplaceholder.typicode.com/posts?userId=${user.id}`);
            if (!postsResponse.ok) {
                throw new Error(`Failed to fetch posts for user ${user.id}`);
            }
            const posts = await postsResponse.json();

            return {
                id: user.id,
                name: user.name,
                posts: posts.map(post => post.title),
            };
        }));

        return usersWithPosts;
    } catch (error) {
        return Promise.reject(error.message);
    }
}

fetchUsersWithPosts()
    .then(data => console.log(data))
    .catch(err => console.error('Error:', err));